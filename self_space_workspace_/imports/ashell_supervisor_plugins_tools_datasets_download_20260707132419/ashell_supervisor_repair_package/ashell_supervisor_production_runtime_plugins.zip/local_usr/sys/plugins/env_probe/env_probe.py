#!/usr/bin/env python3
import datetime, json, pathlib, platform, shutil, sys

root = pathlib.Path.cwd()
payload = {
  "schema_version": "ashell.plugin.env_probe.v1",
  "ok": True,
  "captured_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
  "root": str(root),
  "python": sys.version.split()[0] + ("+" if "+" in sys.version else ""),
  "platform": platform.platform(),
  "commands": {
    "python3": shutil.which("python3"),
    "lg2": shutil.which("lg2"),
    "codex": shutil.which("codex")
  },
  "paths": {
    "local_usr_sys": (root / "local_usr" / "sys").is_dir(),
    "scripts": (root / "scripts").is_dir(),
    "logs": (root / "logs").is_dir(),
    "exports": (root / "exports").is_dir()
  }
}
print(json.dumps(payload, indent=2, ensure_ascii=True))
