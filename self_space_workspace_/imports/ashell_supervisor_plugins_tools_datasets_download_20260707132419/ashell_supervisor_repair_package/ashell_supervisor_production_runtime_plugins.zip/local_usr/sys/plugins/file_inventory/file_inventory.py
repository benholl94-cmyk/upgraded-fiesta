#!/usr/bin/env python3
import datetime, hashlib, json, pathlib

root = pathlib.Path.cwd()
records = []
for path in sorted(root.rglob("*")):
    if ".git" in path.parts or "__pycache__" in path.parts:
        continue
    if path.is_file():
        rel = str(path.relative_to(root))
        records.append({"path": rel, "size_bytes": path.stat().st_size})
payload = {
  "schema_version": "ashell.plugin.file_inventory.v1",
  "ok": True,
  "captured_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z"),
  "file_count": len(records),
  "files": records[:2000],
  "records_sha256": hashlib.sha256(json.dumps(records, sort_keys=True, ensure_ascii=True).encode()).hexdigest()
}
print(json.dumps(payload, indent=2, ensure_ascii=True))
