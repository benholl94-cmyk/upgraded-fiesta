#!/usr/bin/env python3
import datetime, json, pathlib, platform, shutil, sys
root = pathlib.Path.cwd()
payload = {
  "schema_version": "ashell.platform.validation.v1",
  "ok": True,
  "validated_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00","Z"),
  "root": str(root),
  "python": sys.version.split()[0] + ("+" if "+" in sys.version else ""),
  "platform": platform.platform(),
  "is_ios_ashell_hint": "/private/var/mobile/" in str(root) or "iPhone" in platform.platform(),
  "commands": {
    "python3": shutil.which("python3"),
    "lg2": shutil.which("lg2"),
    "codex": shutil.which("codex")
  },
  "paths": {
    "scripts": (root / "scripts").is_dir(),
    "local_usr_sys": (root / "local_usr" / "sys").is_dir(),
    "git": (root / ".git").exists()
  }
}
print(json.dumps(payload, indent=2))
