#!/usr/bin/env python3
import argparse, datetime, hashlib, json, pathlib, platform, shutil, subprocess, sys, zipfile

ROOT = pathlib.Path.cwd()
SYS = ROOT / "local_usr" / "sys"
RUN = SYS / "var" / "run"
LOG = SYS / "var" / "log"
DATA = SYS / "var" / "lib" / "data"
SCHEMA = "ashell.mobile_operator.production.v1"

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00","Z")

def h(v):
    return hashlib.sha256(json.dumps(v, sort_keys=True, ensure_ascii=True, separators=(",",":")).encode()).hexdigest()

def write_json(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(payload)
    payload.setdefault("written_at_utc", utc())
    payload["content_sha256"] = h({k:v for k,v in payload.items() if k != "content_sha256"})
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=True) + "\n")

def append_jsonl(path, payload):
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(payload)
    payload.setdefault("captured_at_utc", utc())
    payload["event_sha256"] = h(payload)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(payload, sort_keys=True, ensure_ascii=True) + "\n")

def run(cmd):
    try:
        p = subprocess.run(cmd, cwd=str(ROOT), text=True, capture_output=True, timeout=30)
        return {"command": cmd, "ok": p.returncode == 0, "exit_code": p.returncode, "stdout": p.stdout.strip()[-4000:], "stderr": p.stderr.strip()[-4000:]}
    except FileNotFoundError:
        return {"command": cmd, "ok": False, "exit_code": None, "stdout": "", "stderr": "command not found"}
    except subprocess.TimeoutExpired:
        return {"command": cmd, "ok": False, "exit_code": None, "stdout": "", "stderr": "timeout"}

def state():
    lg2 = shutil.which("lg2")
    codex = shutil.which("codex")
    git_present = (ROOT / ".git").exists()
    return {
      "schema_version": SCHEMA,
      "root": str(ROOT),
      "python": sys.version.split()[0] + ("+" if "+" in sys.version else ""),
      "platform": platform.platform(),
      "commands": {"python3": shutil.which("python3"), "lg2": lg2, "codex": codex},
      "repo": {
        "git_present": git_present,
        "lg2_status": run(["lg2","status"]) if lg2 and git_present else {"ok": False, "stderr": "skipped: .git missing or lg2 unavailable"}
      },
      "paths": {
        "sys": SYS.is_dir(),
        "run": RUN.is_dir(),
        "log": LOG.is_dir(),
        "data": DATA.is_dir()
      }
    }

def init():
    for p in [SYS/"bin", SYS/"etc", SYS/"etc/policies", SYS/"etc/channels", SYS/"etc/datasets", RUN, LOG, DATA, SYS/"var/lib/channels", SYS/"var/lib/live_sets", SYS/"tmp", SYS/"quarantine"]:
        p.mkdir(parents=True, exist_ok=True)
    manifest = {
      "schema_version": SCHEMA,
      "manifest_id": "iphone_ashell_supervised_workspace",
      "root": str(ROOT),
      "sys_root": str(SYS),
      "policy": {
        "network_required": False,
        "shell_exec_supervised": True,
        "delete_untrusted": False,
        "quarantine_instead_of_delete": True,
        "codex_required": False,
        "git_repo_required": False
      },
      "supervisor": "local_usr/sys/bin/ashell_supervisor.py"
    }
    write_json(SYS/"etc/sys_manifest.json", manifest)
    append_jsonl(LOG/"mobile_operator.events.jsonl", {"event_type": "init", "ok": True})
    return {"ok": True, "manifest": manifest}

def self_test():
    init()
    st = state()
    ok = bool(shutil.which("python3")) and (ROOT/"scripts/mobile_operator.py").is_file()
    out = {"schema_version": SCHEMA, "ok": ok, "checked_at_utc": utc(), "state": st, "errors": [] if ok else ["python3 or mobile_operator missing"]}
    write_json(RUN/"mobile_operator.self_test.json", out)
    append_jsonl(LOG/"mobile_operator.events.jsonl", {"event_type": "self-test", "ok": ok})
    return out

def validate():
    init()
    st = state()
    errors = []
    warnings = []
    if not shutil.which("python3"):
        errors.append("python3 missing")
    if not shutil.which("lg2"):
        warnings.append("lg2 missing; git operations disabled")
    if not (ROOT/".git").exists():
        warnings.append("current workspace is not a git repo; running in Documents-supervised mode")
    for rel in ["scripts/validate_mobile_iphone_platform.py", "scripts/mobile_operator.py", "local_usr/sys/bin/ashell_supervisor.py"]:
        if not (ROOT/rel).exists():
            errors.append(rel + " missing")
    out = {"schema_version": SCHEMA, "ok": not errors, "validated_at_utc": utc(), "errors": errors, "warnings": warnings, "state": st}
    write_json(RUN/"mobile_operator.validation.json", out)
    write_json(DATA/"runtime_state.dataset.json", {"schema_version": SCHEMA, "dataset_id": "runtime_state", "records": st})
    append_jsonl(LOG/"mobile_operator.events.jsonl", {"event_type": "validate", "ok": out["ok"], "errors": errors, "warnings": warnings})
    return out

def audit():
    init()
    records = []
    for p in sorted(ROOT.rglob("*")):
        if ".git" in p.parts or "__pycache__" in p.parts:
            continue
        if p.is_file():
            try:
                records.append({"path": str(p.relative_to(ROOT)), "size_bytes": p.stat().st_size})
            except Exception:
                pass
    out = {"schema_version": SCHEMA, "ok": True, "audited_at_utc": utc(), "file_count": len(records), "files": records[:1000], "state": state()}
    write_json(RUN/"mobile_operator.audit.json", out)
    write_json(DATA/"path_inventory.dataset.json", {"schema_version": SCHEMA, "dataset_id": "path_inventory", "records": records})
    append_jsonl(LOG/"mobile_operator.events.jsonl", {"event_type": "audit", "ok": True, "file_count": len(records)})
    return out

def export():
    audit()
    out_path = ROOT / "exports" / "ashell_supervised_workspace.zip"
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        for base in ["scripts", "local_usr", "logs", "docs", "validation"]:
            p = ROOT / base
            if not p.exists():
                continue
            for child in p.rglob("*"):
                if child.is_file() and "__pycache__" not in child.parts and not child.name.endswith(".pyc"):
                    z.write(child, child.relative_to(ROOT))
    digest = hashlib.sha256(out_path.read_bytes()).hexdigest()
    result = {"schema_version": SCHEMA, "ok": True, "export": {"path": str(out_path), "size_bytes": out_path.stat().st_size, "sha256": digest}}
    write_json(RUN/"mobile_operator.export.json", result)
    append_jsonl(LOG/"mobile_operator.events.jsonl", {"event_type": "export", "ok": True, "sha256": digest})
    return result

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("command", choices=["init","self-test","validate","audit","status","export"])
    a = ap.parse_args()
    if a.command == "init":
        out = init()
    elif a.command == "self-test":
        out = self_test()
    elif a.command == "validate":
        out = validate()
    elif a.command == "audit":
        out = audit()
    elif a.command == "export":
        out = export()
    else:
        out = {"schema_version": SCHEMA, "ok": True, "status": state()}
    print(json.dumps(out, indent=2, ensure_ascii=True))
    return 0 if out.get("ok", True) else 2

if __name__ == "__main__":
    raise SystemExit(main())
