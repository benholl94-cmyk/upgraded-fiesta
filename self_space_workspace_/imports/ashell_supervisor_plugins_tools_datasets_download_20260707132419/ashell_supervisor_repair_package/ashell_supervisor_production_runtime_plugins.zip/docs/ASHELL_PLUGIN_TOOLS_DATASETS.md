# a-Shell Plugin Tools Datasets

Standalone, stdlib-only plugin/tool/dataset layer.

Commands:

```sh
python3 local_usr/sys/bin/plugin_registry.py validate
python3 local_usr/sys/bin/dataset_operator.py validate
python3 local_usr/sys/bin/plugin_runner.py env_probe
python3 local_usr/sys/bin/plugin_runner.py file_inventory
```
