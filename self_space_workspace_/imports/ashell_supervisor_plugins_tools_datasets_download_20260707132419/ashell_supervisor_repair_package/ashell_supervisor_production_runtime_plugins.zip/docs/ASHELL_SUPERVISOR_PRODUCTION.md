# a-Shell Supervisor Production Runtime

Commands:

```sh
python3 local_usr/sys/bin/ashell_supervisor.py init
python3 local_usr/sys/bin/ashell_supervisor.py health
python3 local_usr/sys/bin/ashell_supervisor.py repair
python3 local_usr/sys/bin/ashell_supervisor.py export
python3 local_usr/sys/bin/ashell_supervisor.py serve
```

Routes when serving:

```text
http://127.0.0.1:8097/health
http://127.0.0.1:8097/state
http://127.0.0.1:8097/repair
```
