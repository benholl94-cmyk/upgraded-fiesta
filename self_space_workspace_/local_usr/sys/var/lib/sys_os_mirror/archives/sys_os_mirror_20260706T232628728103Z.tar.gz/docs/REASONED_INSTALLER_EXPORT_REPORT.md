# Reasoned Live-DateTime Installer Export Report

Generated UTC: `2026-07-06T23:26:28.269851Z`

## Result

Gefahrenstufe ist ein Steuerungssignal, kein automatischer Ablehnungsgrund. Blockiert wird nur ein konkret unzulässiger Mechanismus oder Zweck. Hohe Gefahr wird mit Controls, Audit, Operator-Gate und reproduzierbarem Export behandelt.

## Risk Decision

- Decision: `allowed_with_controls`
- Risk level: `high`
- Reason: Risk level controls execution requirements; it is not an automatic refusal.
- Controls: `branch/permission check, commit scope manifest, fail closed, no secret artifacts, redacted logs, rollback note, rotation metadata, secret references only`

## Exports

- `/workspace/exports/reasoned_system_payload_20260706T232628Z.tar.gz` sha256 `2d8516dbd6162639bc8495617b7d9e4fffe35258253b5362ca58d158d3054511`
- `/workspace/exports/reasoned_system_payload_20260706T232628Z.zip` sha256 `e735ff1c76bdca7e97ffecef325a9f9bda5d292ec6eb996bc85c9100c29304e0`

## Install

```sh
python3 install_reasoned_system.py --source reasoned_system_payload --target .
```
