#!/usr/bin/env python3
"""Install the reasoned local_usr/sys control-plane export into a target root."""

from __future__ import annotations

import argparse
import pathlib
import shutil
import sys


def main() -> int:
    parser = argparse.ArgumentParser(description="Install reasoned local_usr/sys export.")
    parser.add_argument("--source", default="reasoned_system_payload", help="Extracted payload directory")
    parser.add_argument("--target", default=".", help="Target project root")
    args = parser.parse_args()
    source = pathlib.Path(args.source).resolve()
    target = pathlib.Path(args.target).resolve()
    if not source.is_dir():
        print({"ok": False, "reason": f"source missing: {source}"})
        return 2
    target.mkdir(parents=True, exist_ok=True)
    for child in source.rglob("*"):
        rel = child.relative_to(source)
        dest = target / rel
        if child.is_dir():
            dest.mkdir(parents=True, exist_ok=True)
            continue
        if any(part in {".git", "__pycache__"} for part in rel.parts):
            continue
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(child, dest)
    print({"ok": True, "source": str(source), "target": str(target)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
